LOGARITMA COFFEE — WEBSITE SEMENTARA

File utama: index.html
Website ini berupa situs statis satu halaman dan belum memakai database/rating/admin.

CARA UPLOAD KE GITHUB (HP):
1. Buka repository: https://github.com/aditya130922-design/LOGARITMA-
2. Pilih Add file > Upload files.
3. Upload index.html dari folder hasil ekstrak ZIP ini.
4. Tekan Commit changes.

CARA DEPLOY DI RENDER:
1. Render Dashboard > New > Static Site.
2. Hubungkan repository LOGARITMA-.
3. Branch: main (atau branch utama yang tampil di GitHub).
4. Build Command: kosongkan.
5. Publish Directory: .
6. Klik Create Static Site.

Setelah deploy berhasil, Render memberikan alamat .onrender.com yang bisa dibuka publik.
